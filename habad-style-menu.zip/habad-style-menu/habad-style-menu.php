<?php
/**
 * Plugin Name:       Style du menu – Beth Habad S Maurice
 * Description:       Menu du haut du site plus grand et plus lisible : majuscules, chevrons fins, sous-menus avec flèches dorées et bouton « Faire un don ». Désactiver l'extension pour revenir à l'ancien style.
 * Version:           1.0.0
 * Author:            Beth Habad S Maurice Plateau
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Chargé après les styles d'Elementor pour pouvoir les remplacer.
add_action( 'wp_enqueue_scripts', function () {
	$deps = wp_style_is( 'elementor-frontend', 'registered' ) ? array( 'elementor-frontend' ) : array();
	wp_enqueue_style( 'habad-style-menu', plugin_dir_url( __FILE__ ) . 'assets/menu.css', $deps, '1.0.0' );
}, 999 );
