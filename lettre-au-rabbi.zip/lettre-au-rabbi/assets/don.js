/* Lettre au Rabbi – don après la lettre (Apple Pay, Google Pay, carte via Stripe) */
(function () {
	var D = window.LAR_DON, box = document.getElementById('lar-don');
	if (!D || !box) return;

	var $ = function (s) { return box.querySelector(s); };
	var pay = $('.lar-pay'), err = $('.lar-pay-err'), btn = $('.lar-paybtn');
	var stripe = null, elements = null, current = null, pi = null, busy = false;
	var fmt = function (c) { return (c / 100).toLocaleString('fr-FR', { minimumFractionDigits: c % 100 ? 2 : 0 }) + ' €'; };

	function post(data) {
		var body = new URLSearchParams(Object.assign({ action: 'lar_don', ref: D.ref }, data));
		return fetch(D.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (j) { if (!j || !j.ok) throw new Error((j && j.error) || 'Une erreur est survenue.'); return j; });
	}
	function uuid() {
		if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); });
	}
	function requestId(cents) {
		var k = 'lar-don-' + D.ref + '-' + cents, v = null;
		try { v = sessionStorage.getItem(k); if (!v) { v = uuid(); sessionStorage.setItem(k, v); } } catch (e) { v = v || uuid(); }
		return v;
	}
	function loadStripe() {
		if (window.Stripe) return Promise.resolve();
		return new Promise(function (ok, ko) {
			var s = document.createElement('script'); s.src = 'https://js.stripe.com/v3/';
			s.onload = ok; s.onerror = function () { ko(new Error('Le paiement ne peut pas être chargé.')); };
			document.head.appendChild(s);
		});
	}
	function select(cents) {
		box.querySelectorAll('.lar-amount-btn').forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.cents === String(cents))); });
	}

	function start(cents) {
		if (busy || cents === current) return;
		current = cents; err.textContent = ''; btn.disabled = true;
		pay.hidden = false; $('.lar-pay-amount').textContent = fmt(cents); btn.textContent = 'Payer ' + fmt(cents);
		$('#lar-express').innerHTML = ''; $('#lar-card').innerHTML = '<p class="lar-small">Chargement du paiement…</p>';
		Promise.all([loadStripe(), post({ op: 'create', cents: cents, requestId: requestId(cents) })]).then(function (r) {
			if (cents !== current) return;
			var j = r[1]; pi = j.paymentIntent;
			stripe = window.Stripe(j.publishableKey);
			elements = stripe.elements({ clientSecret: j.clientSecret, locale: 'fr', appearance: { theme: 'stripe', variables: { colorPrimary: '#14213d', borderRadius: '8px', fontFamily: 'Raleway, system-ui, sans-serif' } } });
			$('#lar-card').innerHTML = '';
			var express = elements.create('expressCheckout', { paymentMethods: { applePay: 'auto', googlePay: 'auto', link: 'never', paypal: 'never', amazonPay: 'never', klarna: 'never' }, buttonHeight: 50 });
			express.mount('#lar-express');
			express.on('confirm', confirm);
			elements.create('payment', { layout: 'tabs', defaultValues: { billingDetails: { email: j.email, name: j.name } } }).mount('#lar-card');
			btn.disabled = false;
		}).catch(function (e) { err.textContent = e.message; $('#lar-card').innerHTML = ''; current = null; });
	}

	function confirm() {
		if (busy || !elements) return;
		busy = true; btn.disabled = true; err.textContent = ''; btn.textContent = 'Paiement en cours…';
		elements.submit().then(function (v) {
			if (v.error) throw v.error;
			return stripe.confirmPayment({ elements: elements, redirect: 'if_required' });
		}).then(function (res) {
			if (res.error) throw res.error;
			return post({ op: 'confirm', pi: pi });
		}).then(function (j) {
			pay.hidden = true; $('.lar-don-amounts').hidden = true; $('.lar-don-autre').hidden = true; box.querySelector('h3').hidden = true; box.querySelector('.lar-help').hidden = true;
			$('.lar-paid-amount').textContent = fmt(j.amountCents);
			var f = $('.lar-cerfa');
			['prenom', 'nom', 'email', 'telephone'].forEach(function (k) { if (j[k]) f.elements[k].value = j[k]; });
			$('.lar-paid').hidden = false;
			box.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}).catch(function (e) {
			err.textContent = (e && e.message) || 'Le paiement n’a pas abouti. Réessayez.';
			btn.textContent = 'Payer ' + fmt(current); btn.disabled = false;
		}).then(function () { busy = false; });
	}

	btn.addEventListener('click', confirm);
	box.querySelectorAll('.lar-amount-btn').forEach(function (b) {
		b.addEventListener('click', function () {
			if (b.dataset.cents === 'autre') { select('autre'); $('.lar-don-autre').hidden = false; $('.lar-don-autre-in').focus(); return; }
			$('.lar-don-autre').hidden = true; select(b.dataset.cents); start(parseInt(b.dataset.cents, 10));
		});
	});
	function autre() {
		var v = Math.round(parseFloat(($('.lar-don-autre-in').value || '').replace(',', '.')) || 0);
		if (v < 1 || v > 20000) { err.textContent = 'Indiquez un montant entre 1 € et 20 000 €.'; pay.hidden = false; return; }
		start(v * 100);
	}
	$('.lar-don-autre-ok').addEventListener('click', autre);
	$('.lar-don-autre-in').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); autre(); } });

	$('.lar-cerfa').addEventListener('submit', function (e) {
		e.preventDefault();
		var f = e.target, msg = $('.lar-cerfa-msg'), b = f.querySelector('button');
		var data = { op: 'cerfa' }; ['prenom', 'nom', 'adresse', 'telephone', 'email'].forEach(function (k) { data[k] = f.elements[k].value.trim(); });
		if (!data.prenom || !data.nom || !data.adresse || data.telephone.replace(/\D/g, '').length < 8) { msg.textContent = 'Merci de remplir prénom, nom, adresse et téléphone.'; return; }
		b.disabled = true; msg.textContent = 'Envoi en cours…';
		post(data).then(function () {
			f.querySelectorAll('input,button').forEach(function (i) { i.disabled = true; });
			msg.textContent = 'Votre reçu fiscal va vous être envoyé par e-mail et sur WhatsApp. Merci !';
		}).catch(function (er) { msg.textContent = er.message; b.disabled = false; });
	});

	// Montant déjà choisi dans le formulaire : le paiement s'affiche directement.
	if (D.don > 0) {
		var preset = box.querySelector('.lar-amount-btn[data-cents="' + D.don + '"]');
		if (preset) select(D.don); else { select('autre'); $('.lar-don-autre').hidden = false; $('.lar-don-autre-in').value = D.don / 100; }
		start(D.don);
	}
})();
