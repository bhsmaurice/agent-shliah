<?php
/**
 * Plugin Name:       Lettre au Rabbi – Beth Habad S Maurice
 * Description:       Page « Écrire au Rabbi » optimisée pour le référencement, formulaire envoyé directement à l'Ohel (ohel@ohelchabad.org) et back office avec toutes les demandes (consultation, recherche, export Excel/CSV).
 * Version:           1.3.0
 * Author:            Beth Habad S Maurice Plateau
 * Text Domain:       lettre-au-rabbi
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LAR_VERSION', '1.3.0' );
define( 'LAR_FILE', __FILE__ );
define( 'LAR_URL', plugin_dir_url( __FILE__ ) );
define( 'LAR_TABLE', 'lettres_rabbi' );
define( 'LAR_DEFAULT_TO', 'ohel@ohelchabad.org' );
define( 'LAR_SLUG', 'ecrire-au-rabbi' );
define( 'LAR_IMG_RABBI', 'https://habadsmaurice.com/wp-content/uploads/2026/11/rabbi.png' );
define( 'LAR_IMG_RABBI2', 'https://habadsmaurice.com/wp-content/uploads/2026/06/IMG_1742.jpeg' );

/* =========================================================================
 * 1. ACTIVATION : table + page automatique
 * ========================================================================= */

register_activation_hook( __FILE__, 'lar_activate' );

define( 'LAR_DB_VERSION', '1.1' );
define( 'LAR_PAY_API', 'https://agent-shliah-production.up.railway.app/don-rabbi/api' );

// Mise à jour automatique de la table quand l'extension évolue.
add_action( 'plugins_loaded', function () {
	if ( get_option( 'lar_db_version' ) !== LAR_DB_VERSION ) {
		lar_create_table();
	}
} );

function lar_create_table() {
	global $wpdb;
	$table   = $wpdb->prefix . LAR_TABLE;
	$charset = $wpdb->get_charset_collate();

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( "CREATE TABLE $table (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		created_at DATETIME NOT NULL,
		prenom VARCHAR(100) NOT NULL DEFAULT '',
		nom VARCHAR(100) NOT NULL DEFAULT '',
		email VARCHAR(190) NOT NULL DEFAULT '',
		telephone VARCHAR(40) NOT NULL DEFAULT '',
		ville VARCHAR(100) NOT NULL DEFAULT '',
		nom_hebreu VARCHAR(150) NOT NULL DEFAULT '',
		nom_mere VARCHAR(150) NOT NULL DEFAULT '',
		personnes TEXT NULL,
		lettre LONGTEXT NULL,
		mail_sent TINYINT(1) NOT NULL DEFAULT 0,
		ip VARCHAR(64) NOT NULL DEFAULT '',
		don_cents INT UNSIGNED NOT NULL DEFAULT 0,
		don_statut VARCHAR(20) NOT NULL DEFAULT '',
		don_pi VARCHAR(80) NOT NULL DEFAULT '',
		PRIMARY KEY  (id),
		KEY created_at (created_at),
		KEY email (email)
	) $charset;" );
	update_option( 'lar_db_version', LAR_DB_VERSION );
}

function lar_activate() {
	lar_create_table();

	add_option( 'lar_settings', array(
		'to'      => LAR_DEFAULT_TO,
		'copy'    => '',
		'confirm' => 1,
	) );

	// Création automatique de la page si elle n'existe pas encore.
	if ( ! get_page_by_path( LAR_SLUG ) ) {
		$page_id = wp_insert_post( array(
			'post_title'   => 'Écrire au Rabbi',
			'post_name'    => LAR_SLUG,
			'post_content' => '[lettre_au_rabbi]',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_excerpt' => lar_meta_description(),
		) );
		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_option( 'lar_page_id', $page_id );
			// Pré-remplissage SEO pour Yoast et Rank Math s'ils sont installés.
			update_post_meta( $page_id, '_yoast_wpseo_title', lar_seo_title() );
			update_post_meta( $page_id, '_yoast_wpseo_metadesc', lar_meta_description() );
			update_post_meta( $page_id, '_yoast_wpseo_focuskw', 'écrire au Rabbi' );
			update_post_meta( $page_id, 'rank_math_title', lar_seo_title() );
			update_post_meta( $page_id, 'rank_math_description', lar_meta_description() );
			update_post_meta( $page_id, 'rank_math_focus_keyword', 'écrire au Rabbi,lettre au Rabbi,Ohel' );
		}
	}
}

function lar_settings() {
	$s = get_option( 'lar_settings', array() );
	return wp_parse_args( $s, array( 'to' => LAR_DEFAULT_TO, 'copy' => '', 'confirm' => 1 ) );
}

/* =========================================================================
 * 2. SEO
 * ========================================================================= */

function lar_seo_title() {
	return 'Écrire au Rabbi de Loubavitch – Envoyer une lettre à l\'Ohel | Beth Habad S Maurice';
}

function lar_meta_description() {
	return 'Écrivez au Rabbi de Loubavitch en ligne : votre lettre est transmise directement à l\'Ohel à New York. Formulaire gratuit et confidentiel, conseils pour écrire votre lettre (nom hébreu, bénédiction). Beth Habad S Maurice.';
}

function lar_is_page() {
	if ( ! is_singular() ) {
		return false;
	}
	$post = get_post();
	return $post && has_shortcode( $post->post_content, 'lettre_au_rabbi' );
}

function lar_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

// Titre de l'onglet (si aucun plugin SEO ne le gère).
add_filter( 'pre_get_document_title', function ( $title ) {
	if ( lar_is_page() && ! lar_seo_plugin_active() ) {
		return lar_seo_title();
	}
	return $title;
}, 20 );

add_action( 'wp_head', 'lar_head', 2 );
function lar_head() {
	if ( ! lar_is_page() ) {
		return;
	}
	$url  = get_permalink();
	$desc = lar_meta_description();

	if ( ! lar_seo_plugin_active() ) {
		echo "\n<meta name=\"description\" content=\"" . esc_attr( $desc ) . "\" />\n";
		echo '<meta name="robots" content="index, follow, max-image-preview:large" />' . "\n";
		echo '<link rel="canonical" href="' . esc_url( $url ) . '" />' . "\n";
		echo '<meta property="og:type" content="website" />' . "\n";
		echo '<meta property="og:locale" content="fr_FR" />' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( 'Écrire au Rabbi – Envoyer une lettre à l\'Ohel' ) . '" />' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '" />' . "\n";
		echo '<meta property="og:url" content="' . esc_url( $url ) . '" />' . "\n";
		echo '<meta property="og:site_name" content="Beth Habad S Maurice" />' . "\n";
		echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
		echo '<meta property="og:image" content="' . esc_url( LAR_IMG_RABBI ) . '" />' . "\n";
	}

	// Données structurées : WebPage + Organisation locale + FAQ + étapes HowTo.
	$faq = array();
	foreach ( lar_faq() as $q ) {
		$faq[] = array(
			'@type'          => 'Question',
			'name'           => $q[0],
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => wp_strip_all_tags( $q[1] ) ),
		);
	}
	$steps = array();
	foreach ( lar_steps() as $i => $st ) {
		$steps[] = array( '@type' => 'HowToStep', 'position' => $i + 1, 'name' => $st[0], 'text' => wp_strip_all_tags( $st[1] ) );
	}

	$graph = array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			array(
				'@type'       => 'WebPage',
				'@id'         => $url . '#webpage',
				'url'         => $url,
				'name'        => 'Écrire au Rabbi de Loubavitch – Envoyer une lettre à l\'Ohel',
				'description' => $desc,
				'inLanguage'  => 'fr-FR',
				'about'       => array( '@type' => 'Thing', 'name' => 'Lettre au Rabbi de Loubavitch (Ohel)' ),
				'primaryImageOfPage' => array( '@type' => 'ImageObject', 'url' => LAR_IMG_RABBI ),
				'publisher'   => array( '@id' => home_url( '/#organization' ) ),
			),
			array(
				'@type'     => array( 'PlaceOfWorship', 'Synagogue' ),
				'@id'       => home_url( '/#organization' ),
				'name'      => 'Beth Habad S Maurice Plateau',
				'url'       => home_url( '/' ),
				'email'     => 'bhsmaurice@gmail.com',
				'sameAs'    => array( 'https://www.instagram.com/habadsmaurice' ),
				'address'   => array(
					'@type'           => 'PostalAddress',
					'streetAddress'   => '30 avenue du Maréchal de Lattre de Tassigny',
					'postalCode'      => '94410',
					'addressLocality' => 'Saint-Maurice',
					'addressRegion'   => 'Val-de-Marne',
					'addressCountry'  => 'FR',
				),
				'areaServed' => array( 'Saint-Maurice', 'Charenton-le-Pont', 'Maisons-Alfort', 'Alfortville', 'Joinville-le-Pont', 'Val-de-Marne' ),
			),
			array(
				'@type'      => 'HowTo',
				'name'       => 'Comment écrire une lettre au Rabbi',
				'inLanguage' => 'fr-FR',
				'step'       => $steps,
			),
			array(
				'@type'      => 'FAQPage',
				'mainEntity' => $faq,
			),
		),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
}

/* =========================================================================
 * 3. CONTENU DE LA PAGE
 * ========================================================================= */

function lar_steps() {
	return array(
		array( 'Se préparer', 'Prenez un moment de calme. Beaucoup ont la coutume de donner un peu de <strong>tsedaka</strong> avant d\'écrire et de prendre une bonne résolution (une mitsva, une étude de Torah…).' ),
		array( 'Indiquer son nom hébreu', 'On se présente avec son <strong>prénom hébreu</strong> suivi du prénom hébreu de sa <strong>mère</strong> : « Moché ben Sarah », « Rivka bat Léa ». Si vous ne le connaissez pas, indiquez simplement votre prénom.' ),
		array( 'Écrire avec le cœur', 'Écrivez librement, dans la langue de votre choix : remerciements, demande de bénédiction pour la santé, la parnassa, le mariage, les enfants, une décision importante…' ),
		array( 'Mentionner ses proches', 'Vous pouvez demander une bénédiction pour d\'autres personnes en indiquant leur nom hébreu et celui de leur mère.' ),
		array( 'Envoyer', 'Votre lettre est transmise directement à l\'Ohel, où elle est imprimée et déposée sur le lieu de repos du Rabbi.' ),
	);
}

function lar_faq() {
	return array(
		array( 'Peut-on encore écrire au Rabbi aujourd\'hui ?', 'Oui. Chaque jour, des milliers de personnes du monde entier envoient une lettre au Rabbi de Loubavitch. Les lettres sont lues et déposées à l\'Ohel, à New York, comme le faisaient déjà les ’hassidim auprès des Rabbis précédents.' ),
		array( 'Faut-il être pratiquant pour écrire au Rabbi ?', 'Non. Le Rabbi a toujours accueilli chaque Juif, quel que soit son niveau de pratique. Il suffit d\'écrire sincèrement.' ),
		array( 'Dans quelle langue écrire ?', 'Dans la langue dans laquelle vous vous exprimez le mieux : français, hébreu, anglais, russe… L\'essentiel est que la lettre vienne du cœur.' ),
		array( 'Que signifie « ben » ou « bat » ?', '« Ben » signifie « fils de » et « bat » « fille de ». On indique son prénom hébreu suivi de celui de sa mère, par exemple « David ben ’Hana ».' ),
		array( 'Est-ce payant ?', 'Non, l\'envoi est entièrement gratuit. Il est d\'usage de donner un peu de tsedaka avant d\'écrire, à l\'œuvre de votre choix.' ),
		array( 'Ma lettre est-elle confidentielle ?', 'Oui. Votre lettre est envoyée directement à l\'Ohel. Une copie est conservée de manière strictement confidentielle par le Beth Habad, uniquement pour le suivi de votre envoi ; elle n\'est jamais partagée.' ),
		array( 'Que faire après avoir écrit ?', 'Prendre sur soi une bonne résolution et la tenir. Beaucoup ont aussi la coutume d\'ouvrir un volume des Iguérot Kodech (les lettres du Rabbi). Le Rav du Beth Habad S Maurice est à votre écoute si vous souhaitez en parler.' ),
	);
}

add_shortcode( 'lettre_au_rabbi', 'lar_shortcode' );
function lar_icon( $name ) {
	$i = array(
		'gift'   => '<path d="M20 12v9H4v-9M2 7h20v5H2zM12 21V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/>',
		'lock'   => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
		'send'   => '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
		'heart'  => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21.2l8.8-8.8a5.5 5.5 0 0 0 0-7.8z"/>',
		'tent'   => '<path d="M3 20 12 4l9 16M12 4v16M8 20l4-7 4 7"/>',
		'book'   => '<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2zM22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
		'check'  => '<path d="M20 6 9 17l-5-5"/>',
		'mail'   => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/>',
		'phone'  => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
	);
	return '<svg class="lar-ico" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $i[ $name ] ?? '' ) . '</svg>';
}

function lar_shortcode() {
	wp_enqueue_style( 'lar-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,500;1,600&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap', array(), null );
	wp_enqueue_style( 'lar-front', LAR_URL . 'assets/front.css', array(), LAR_VERSION );

	$status  = isset( $_GET['lettre'] ) ? sanitize_key( $_GET['lettre'] ) : '';
	$ref     = isset( $_GET['ref'] ) ? sanitize_text_field( wp_unslash( $_GET['ref'] ) ) : '';
	$ref_id  = lar_check_ref( $ref );
	$don     = isset( $_GET['don'] ) ? min( 2000000, absint( $_GET['don'] ) ) : 0;
	$action  = esc_url( admin_url( 'admin-post.php' ) );
	$current = esc_url( get_permalink() );

	ob_start();
	?>
	<div class="lar-wrap">

		<!-- ============ EN-TÊTE ============ -->
		<header class="lar-hero">
			<div class="lar-in lar-hero-grid">
				<div class="lar-hero-text">
					<p class="lar-kicker"><span></span>Beth Habad S Maurice · Lettre au Rabbi</p>
					<h1>Écrire au Rabbi <em>de Loubavitch</em></h1>
					<p class="lar-lead">Confiez au Rabbi vos prières, vos remerciements et vos demandes de bénédiction. Votre lettre est transmise <strong>directement à l'Ohel</strong>, à New York, et déposée sur le lieu de repos du Rabbi.</p>
					<div class="lar-hero-btns">
						<a class="lar-btn" href="#lar-formulaire">Écrire ma lettre</a>
						<a class="lar-btn lar-btn-ghost" href="#lar-comment">Comment ça marche&nbsp;?</a>
					</div>
				</div>
				<div class="lar-hero-art">
					<figure class="lar-portrait">
						<img src="<?php echo esc_url( LAR_IMG_RABBI ); ?>" width="500" height="750" alt="Le Rabbi de Loubavitch, Rabbi Mena'hem Mendel Schneerson" fetchpriority="high" decoding="async">
					</figure>
					<div class="lar-paper" aria-hidden="true">
						<div class="lar-paper-bh">ב״ה</div>
						<p class="lar-paper-title">Au Rabbi de Loubavitch,</p>
						<span class="lar-line" style="width:92%"></span><span class="lar-line" style="width:84%"></span><span class="lar-line" style="width:88%"></span><span class="lar-line" style="width:70%"></span><span class="lar-line" style="width:90%"></span><span class="lar-line" style="width:56%"></span>
						<p class="lar-paper-sign">Moché ben Sarah</p>
						<div class="lar-seal"><span>✦</span></div>
					</div>
				</div>
			</div>
		</header>

		<!-- ============ CONFIANCE ============ -->
		<div class="lar-trust">
			<div class="lar-in lar-trust-grid">
				<div><?php echo lar_icon( 'gift' ); ?><strong>Gratuit</strong><span>Sans inscription</span></div>
				<div><?php echo lar_icon( 'lock' ); ?><strong>Confidentiel</strong><span>Jamais partagé</span></div>
				<div><?php echo lar_icon( 'send' ); ?><strong>Transmis à l'Ohel</strong><span>New York</span></div>
				<div><?php echo lar_icon( 'heart' ); ?><strong>Tsedaka</strong><span>Apple Pay, carte</span></div>
			</div>
		</div>

		<!-- ============ INTRODUCTION ============ -->
		<section class="lar-sec lar-intro">
			<div class="lar-in lar-intro-grid">
				<figure class="lar-photo">
					<img src="<?php echo esc_url( LAR_IMG_RABBI2 ); ?>" width="1410" height="2048" alt="Le Rabbi de Loubavitch" loading="lazy" decoding="async">
				</figure>
				<div class="lar-intro-text">
				<p class="lar-eyebrow">Une tradition vivante</p>
				<h2>Une lettre au Rabbi, une bénédiction pour votre vie</h2>
				<div class="lar-orn" aria-hidden="true"><span>✦</span></div>
				<p>Depuis des générations, les ’hassidim et des Juifs de tous horizons écrivent au Rabbi pour lui confier leurs joies, leurs inquiétudes et leurs projets, et pour demander sa <strong>bénédiction (brakha)</strong>. Aujourd'hui encore, des milliers de lettres arrivent chaque jour à l'<strong>Ohel</strong>, le lieu de repos du Rabbi de Loubavitch, Rabbi Mena'hem Mendel Schneerson, dans le Queens à New York.</p>
				<p>Santé, parnassa, mariage, naissance, décision importante ou simple remerciement&nbsp;: vous pouvez écrire au Rabbi depuis S Maurice, Charenton, Maisons-Alfort ou d'ailleurs, grâce au formulaire ci-dessous.</p>
				<a class="lar-link" href="#lar-formulaire">Écrire ma lettre maintenant <span>→</span></a>
				</div>
			</div>
		</section>

		<!-- ============ FORMULAIRE ============ -->
		<section class="lar-sec lar-form-sec" id="lar-formulaire">
			<div class="lar-in lar-form-grid">
				<div class="lar-card lar-form-card">
					<p class="lar-eyebrow">Formulaire</p>
					<h2>Envoyer ma lettre à l'Ohel</h2>

					<?php if ( 'ok' === $status ) : ?>
						<div class="lar-alert lar-alert-ok" role="status">
							<?php echo lar_icon( 'check' ); ?>
							<div><strong>Votre lettre a bien été envoyée à l'Ohel.</strong><br>
							Qu'Hachem accorde toutes vos demandes pour le bien. Prenez une bonne résolution et n'hésitez pas à nous contacter si vous souhaitez en parler.</div>
						</div>
						<?php if ( $ref_id ) : ?>
							<?php echo lar_don_panel( $ref, $don ); // phpcs:ignore ?>
						<?php endif; ?>
						<p class="lar-small"><a href="<?php echo $current; ?>#lar-formulaire">Écrire une autre lettre</a></p>
					<?php else : ?>
						<?php if ( 'erreur' === $status ) : ?>
							<div class="lar-alert lar-alert-err" role="alert">Merci de remplir tous les champs obligatoires (prénom, nom, e-mail, lettre) et de cocher la case de consentement.</div>
						<?php elseif ( 'limite' === $status ) : ?>
							<div class="lar-alert lar-alert-err" role="alert">Vous avez envoyé plusieurs lettres en peu de temps. Merci de réessayer un peu plus tard.</div>
						<?php endif; ?>

					<form class="lar-form" method="post" action="<?php echo $action; ?>" novalidate>
						<input type="hidden" name="action" value="lar_submit">
						<input type="hidden" name="lar_back" value="<?php echo $current; ?>">
						<input type="hidden" name="lar_js" value="" class="lar-js">
						<div class="lar-hp" aria-hidden="true"><label>Site web <input type="text" name="lar_website" tabindex="-1" autocomplete="off"></label></div>

						<fieldset>
							<legend><b>01</b>Vos coordonnées</legend>
							<div class="lar-grid">
								<label><span class="lar-lab">Prénom <i>*</i></span><input type="text" name="prenom" required maxlength="100" autocomplete="given-name"></label>
								<label><span class="lar-lab">Nom <i>*</i></span><input type="text" name="nom" required maxlength="100" autocomplete="family-name"></label>
								<label><span class="lar-lab">E-mail <i>*</i></span><input type="email" name="email" required maxlength="190" autocomplete="email"></label>
								<label><span class="lar-lab">Téléphone <em>facultatif</em></span><input type="tel" name="telephone" maxlength="40" autocomplete="tel"></label>
								<label class="lar-full"><span class="lar-lab">Ville <em>facultatif</em></span><input type="text" name="ville" maxlength="100" autocomplete="address-level2"></label>
							</div>
						</fieldset>

						<fieldset>
							<legend><b>02</b>Votre nom hébreu</legend>
							<p class="lar-help">On se présente au Rabbi avec son prénom hébreu et celui de sa mère (ex.&nbsp;: Moché <em>ben</em> Sarah, Rivka <em>bat</em> Léa).</p>
							<div class="lar-grid">
								<label><span class="lar-lab">Votre prénom hébreu</span><input type="text" name="nom_hebreu" maxlength="150" dir="auto" placeholder="ex. Moché / משה"></label>
								<label><span class="lar-lab">Prénom hébreu de votre mère</span><input type="text" name="nom_mere" maxlength="150" dir="auto" placeholder="ex. Sarah / שרה"></label>
							</div>
						</fieldset>

						<fieldset>
							<legend><b>03</b>Votre lettre</legend>
							<label class="lar-full"><span class="lar-lab">Proches pour qui vous demandez une bénédiction <em>facultatif</em></span>
								<textarea name="personnes" rows="3" maxlength="3000" dir="auto" placeholder="ex. David ben ’Hana – santé ; Léa bat Myriam – mariage"></textarea>
							</label>
							<label class="lar-full"><span class="lar-lab">Votre lettre au Rabbi <i>*</i></span>
								<textarea name="lettre" rows="10" required maxlength="20000" dir="auto" class="lar-letter-area" placeholder="Écrivez librement, dans la langue de votre choix…"></textarea>
							</label>
						</fieldset>

						<fieldset class="lar-tsedaka">
							<legend><b>04</b>Une tsedaka <em>facultatif</em></legend>
							<p class="lar-help">Il est d'usage de donner la tsedaka avant d'écrire au Rabbi. Choisissez un montant&nbsp;: vous pourrez payer juste après l'envoi, par <strong>Apple&nbsp;Pay</strong>, Google&nbsp;Pay ou carte bancaire.</p>
							<div class="lar-amounts" role="radiogroup" aria-label="Montant du don">
								<label class="lar-amount"><input type="radio" name="don_choix" value="0" checked><span>Pas cette fois</span></label>
								<?php foreach ( lar_amounts() as $a ) : ?>
									<label class="lar-amount"><input type="radio" name="don_choix" value="<?php echo (int) $a; ?>"><span><?php echo (int) $a; ?>&nbsp;€</span></label>
								<?php endforeach; ?>
								<label class="lar-amount"><input type="radio" name="don_choix" value="autre"><span>Autre</span></label>
							</div>
							<label class="lar-autre" hidden><span class="lar-lab">Montant de votre choix (en €)</span>
								<input type="number" name="don_autre" min="1" max="20000" step="1" inputmode="numeric" placeholder="ex. 26">
							</label>
						</fieldset>

						<label class="lar-check">
							<input type="checkbox" name="consent" value="1" required>
							<span>J'accepte que ma lettre soit transmise à l'Ohel (ohel@ohelchabad.org) et qu'une copie soit conservée de manière confidentielle par le Beth Habad S Maurice pour le suivi de mon envoi. *</span>
						</label>

						<button type="submit" class="lar-btn lar-submit">Envoyer ma lettre au Rabbi</button>
						<p class="lar-small">* Champs obligatoires. Vos données ne sont jamais revendues ni partagées.</p>
					</form>
					<?php endif; ?>
				</div>

				<aside class="lar-aside">
					<div class="lar-card lar-aside-card">
						<p class="lar-eyebrow">Avant d'écrire</p>
						<h3>Quelques conseils</h3>
						<ul class="lar-tips">
							<li><?php echo lar_icon( 'heart' ); ?><span>Donnez un peu de <strong>tsedaka</strong> et prenez une bonne résolution.</span></li>
							<li><?php echo lar_icon( 'book' ); ?><span>Indiquez votre <strong>prénom hébreu</strong> et celui de votre mère.</span></li>
							<li><?php echo lar_icon( 'mail' ); ?><span>Écrivez <strong>avec le cœur</strong>, dans la langue de votre choix.</span></li>
						</ul>
						<div class="lar-aside-help">
							<p>Besoin d'aide pour votre nom hébreu ou votre lettre&nbsp;?</p>
							<a href="mailto:bhsmaurice@gmail.com"><?php echo lar_icon( 'mail' ); ?>bhsmaurice@gmail.com</a>
							<a href="tel:+33770241746"><?php echo lar_icon( 'phone' ); ?>07 70 24 17 46</a>
						</div>
					</div>
				</aside>
			</div>
		</section>

		<!-- ============ ÉTAPES ============ -->
		<section class="lar-sec" id="lar-comment">
			<div class="lar-in">
				<div class="lar-head">
					<p class="lar-eyebrow">Pas à pas</p>
					<h2>Comment écrire une lettre au Rabbi&nbsp;?</h2>
				</div>
				<ol class="lar-steps">
					<?php foreach ( lar_steps() as $n => $st ) : ?>
						<li><span class="lar-step-n"><?php echo esc_html( str_pad( (string) ( $n + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><h3><?php echo esc_html( $st[0] ); ?></h3><p><?php echo wp_kses_post( $st[1] ); ?></p></li>
					<?php endforeach; ?>
				</ol>
			</div>
		</section>

		<!-- ============ OHEL & IGUÉROT ============ -->
		<section class="lar-sec lar-cream">
			<div class="lar-in lar-two">
				<article class="lar-card lar-info">
					<div class="lar-info-ico"><?php echo lar_icon( 'tent' ); ?></div>
					<h2>Qu'est-ce que l'Ohel&nbsp;?</h2>
					<p>L'<strong>Ohel</strong> («&nbsp;la tente&nbsp;») désigne le lieu de repos du Rabbi de Loubavitch et de son beau-père, le Rabbi précédent, au cimetière Montefiore, dans le Queens à New York. Depuis le 3 Tamouz 5754 (1994), des personnes du monde entier s'y rendent pour prier et y déposer leurs lettres.</p>
					<p>Ne pouvant pas tous faire le voyage, beaucoup envoient leur lettre à distance&nbsp;: elle est alors imprimée et apportée sur place, exactement comme si vous étiez venu.</p>
				</article>
				<article class="lar-card lar-info">
					<div class="lar-info-ico"><?php echo lar_icon( 'book' ); ?></div>
					<h2>Les Iguérot Kodech</h2>
					<p>Le Rabbi a répondu de son vivant à des centaines de milliers de lettres. Une partie de cette correspondance a été publiée dans les <strong>Iguérot Kodech</strong> («&nbsp;Lettres saintes&nbsp;»).</p>
					<p>Après avoir écrit, beaucoup ont la coutume d'ouvrir un de ces volumes et d'y trouver un conseil ou une réponse à leur question.</p>
				</article>
			</div>
		</section>

		<!-- ============ FAQ ============ -->
		<section class="lar-sec">
			<div class="lar-in lar-narrow">
				<div class="lar-head">
					<p class="lar-eyebrow">Vos questions</p>
					<h2>Questions fréquentes</h2>
				</div>
				<div class="lar-faq">
					<?php foreach ( lar_faq() as $q ) : ?>
						<details><summary><?php echo esc_html( $q[0] ); ?></summary><p><?php echo wp_kses_post( $q[1] ); ?></p></details>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

		<!-- ============ APPEL FINAL ============ -->
		<section class="lar-cta">
			<div class="lar-in lar-narrow">
				<div class="lar-orn lar-orn-light" aria-hidden="true"><span>✦</span></div>
				<h2>Besoin d'aide pour écrire votre lettre&nbsp;?</h2>
				<p>Le Rav Levi Basanger et l'équipe du Beth Habad S Maurice Plateau sont à votre écoute pour vous aider à trouver votre nom hébreu ou à rédiger votre lettre.</p>
				<div class="lar-hero-btns lar-center">
					<a class="lar-btn" href="#lar-formulaire">Écrire ma lettre</a>
					<a class="lar-btn lar-btn-ghost" href="mailto:bhsmaurice@gmail.com">Nous écrire</a>
				</div>
				<p class="lar-contact">Beth Habad S Maurice Plateau · 30 avenue du Maréchal de Lattre de Tassigny, 94410 S Maurice · <a href="https://www.instagram.com/habadsmaurice" target="_blank" rel="noopener">Instagram</a></p>
			</div>
		</section>

	</div>
	<script>
	(function(){
		<?php if ( $status ) : ?>var s=document.getElementById('lar-formulaire'); if(s) s.scrollIntoView();<?php endif; ?>
		var f=document.querySelector('.lar-form'); if(!f) return;
		var t=f.querySelector('.lar-js'); if(t) t.value='ok-'+Date.now();
		var b=f.querySelector('.lar-submit'), autre=f.querySelector('.lar-autre'), autreIn=f.querySelector('[name="don_autre"]');
		function montant(){var c=f.querySelector('[name="don_choix"]:checked'); if(!c||c.value==='0') return 0; if(c.value==='autre') return Math.max(0,Math.round(parseFloat((autreIn.value||'').replace(',','.'))||0)); return parseInt(c.value,10)||0;}
		function maj(){var c=f.querySelector('[name="don_choix"]:checked'); autre.hidden=!(c&&c.value==='autre'); var m=montant(); b.textContent=m>0?('Envoyer ma lettre et donner '+m+' €'):'Envoyer ma lettre au Rabbi';}
		f.addEventListener('change',maj); autreIn.addEventListener('input',maj);
		f.addEventListener('submit',function(){b.disabled=true;b.textContent='Envoi en cours…';});
	})();
	</script>
	<?php
	return ob_get_clean();
}

/* =========================================================================
 * 4. TRAITEMENT DU FORMULAIRE
 * ========================================================================= */

add_action( 'admin_post_nopriv_lar_submit', 'lar_handle_submit' );
add_action( 'admin_post_lar_submit', 'lar_handle_submit' );

function lar_client_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

function lar_handle_submit() {
	$back = isset( $_POST['lar_back'] ) ? esc_url_raw( wp_unslash( $_POST['lar_back'] ) ) : home_url( '/' . LAR_SLUG . '/' );
	$back = wp_validate_redirect( $back, home_url( '/' ) );
	$go   = function ( $code, $extra = array() ) use ( $back ) {
		$back = remove_query_arg( array( 'lettre', 'ref', 'don' ), $back );
		wp_safe_redirect( add_query_arg( array_merge( array( 'lettre' => $code ), $extra ), $back ) . '#lar-formulaire' );
		exit;
	};

	// Anti-spam : champ piège + vérification JavaScript (compatible avec les plugins de cache).
	$hp = isset( $_POST['lar_website'] ) ? trim( (string) wp_unslash( $_POST['lar_website'] ) ) : '';
	$js = isset( $_POST['lar_js'] ) ? (string) wp_unslash( $_POST['lar_js'] ) : '';
	if ( '' !== $hp || 0 !== strpos( $js, 'ok-' ) ) {
		$go( 'ok' ); // On fait croire au robot que c'est passé.
	}

	// Limite : 5 envois par heure et par adresse IP.
	$ip  = lar_client_ip();
	$key = 'lar_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		$go( 'limite' );
	}

	$f = array(
		'prenom'     => sanitize_text_field( wp_unslash( $_POST['prenom'] ?? '' ) ),
		'nom'        => sanitize_text_field( wp_unslash( $_POST['nom'] ?? '' ) ),
		'email'      => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
		'telephone'  => sanitize_text_field( wp_unslash( $_POST['telephone'] ?? '' ) ),
		'ville'      => sanitize_text_field( wp_unslash( $_POST['ville'] ?? '' ) ),
		'nom_hebreu' => sanitize_text_field( wp_unslash( $_POST['nom_hebreu'] ?? '' ) ),
		'nom_mere'   => sanitize_text_field( wp_unslash( $_POST['nom_mere'] ?? '' ) ),
		'personnes'  => sanitize_textarea_field( wp_unslash( $_POST['personnes'] ?? '' ) ),
		'lettre'     => sanitize_textarea_field( wp_unslash( $_POST['lettre'] ?? '' ) ),
	);

	if ( '' === $f['prenom'] || '' === $f['nom'] || ! is_email( $f['email'] ) || '' === trim( $f['lettre'] ) || empty( $_POST['consent'] ) ) {
		$go( 'erreur' );
	}

	set_transient( $key, $n + 1, HOUR_IN_SECONDS );

	// Don choisi (facultatif), en centimes.
	$choix = isset( $_POST['don_choix'] ) ? sanitize_text_field( wp_unslash( $_POST['don_choix'] ) ) : '0';
	$euros = 'autre' === $choix ? (float) str_replace( ',', '.', sanitize_text_field( wp_unslash( $_POST['don_autre'] ?? '0' ) ) ) : (float) $choix;
	$don   = ( $euros >= 1 && $euros <= 20000 ) ? (int) round( $euros ) * 100 : 0;

	global $wpdb;
	$table = $wpdb->prefix . LAR_TABLE;
	$wpdb->insert( $table, array_merge( $f, array(
		'created_at' => current_time( 'mysql' ),
		'mail_sent'  => 0,
		'ip'         => $ip,
		'don_cents'  => $don,
		'don_statut' => $don ? 'choisi' : '',
	) ) );
	$id = (int) $wpdb->insert_id;

	$sent = lar_send_to_ohel( $f );
	if ( $id ) {
		$wpdb->update( $table, array( 'mail_sent' => $sent ? 1 : 0 ), array( 'id' => $id ) );
	}

	$s = lar_settings();
	if ( ! empty( $s['confirm'] ) ) {
		lar_send_confirmation( $f, $id, $don );
	}

	$go( 'ok', $id ? array( 'ref' => lar_make_ref( $id ), 'don' => $don ) : array() );
}

/* =========================================================================
 * 4 bis. DON APRÈS LA LETTRE (Stripe via le serveur Agent Shliah)
 * ========================================================================= */

function lar_amounts() {
	return array( 18, 36, 52, 100, 180 );
}

function lar_make_ref( $id ) {
	return (int) $id . '-' . substr( wp_hash( 'lar-ref-' . (int) $id ), 0, 16 );
}

function lar_check_ref( $ref ) {
	if ( ! preg_match( '/^(\d+)-([a-f0-9]{16})$/', (string) $ref, $m ) ) {
		return 0;
	}
	return hash_equals( lar_make_ref( $m[1] ), $ref ) ? (int) $m[1] : 0;
}

function lar_don_panel( $ref, $don_cents ) {
	wp_enqueue_script( 'lar-don', LAR_URL . 'assets/don.js', array(), LAR_VERSION, true );
	wp_localize_script( 'lar-don', 'LAR_DON', array(
		'ajax' => admin_url( 'admin-ajax.php' ),
		'ref'  => $ref,
		'don'  => (int) $don_cents,
	) );
	ob_start();
	?>
	<div class="lar-don" id="lar-don">
		<h3><?php echo $don_cents ? 'Votre tsedaka' : 'Accompagner votre lettre d\'une tsedaka&nbsp;?'; ?></h3>
		<p class="lar-help">Paiement sécurisé par <strong>Apple&nbsp;Pay</strong>, Google&nbsp;Pay ou carte bancaire. Un reçu fiscal (Cerfa) peut vous être envoyé.</p>
		<div class="lar-amounts lar-don-amounts">
			<?php foreach ( lar_amounts() as $a ) : ?>
				<button type="button" class="lar-amount-btn" data-cents="<?php echo (int) $a * 100; ?>"><?php echo (int) $a; ?>&nbsp;€</button>
			<?php endforeach; ?>
			<button type="button" class="lar-amount-btn" data-cents="autre">Autre</button>
		</div>
		<div class="lar-don-autre" hidden>
			<label>Montant de votre choix (en €)<input type="number" min="1" max="20000" step="1" inputmode="numeric" class="lar-don-autre-in" placeholder="ex. 26"></label>
			<button type="button" class="lar-btn lar-don-autre-ok">Valider</button>
		</div>
		<div class="lar-pay" hidden>
			<p class="lar-pay-total">Votre don&nbsp;: <strong class="lar-pay-amount"></strong></p>
			<div id="lar-express"></div>
			<p class="lar-or"><span>ou par carte bancaire</span></p>
			<div id="lar-card"></div>
			<button type="button" class="lar-btn lar-submit lar-paybtn" disabled>Payer</button>
			<p class="lar-pay-err" role="alert"></p>
			<p class="lar-small">🔒 Paiement sécurisé par Stripe</p>
		</div>
		<div class="lar-paid" hidden>
			<div class="lar-alert lar-alert-ok"><strong>Merci pour votre tsedaka de <span class="lar-paid-amount"></span>&nbsp;!</strong><br>Tizkou lemitsvot.</div>
			<form class="lar-cerfa">
				<h4>Recevoir mon reçu fiscal (Cerfa)</h4>
				<div class="lar-grid">
					<label>Prénom<input name="prenom" required maxlength="100"></label>
					<label>Nom<input name="nom" required maxlength="100"></label>
					<label class="lar-full">Adresse postale complète<input name="adresse" required maxlength="250" placeholder="N°, rue, code postal, ville"></label>
					<label>Téléphone (WhatsApp)<input name="telephone" type="tel" required maxlength="30"></label>
					<label>E-mail<input name="email" type="email" maxlength="160"></label>
				</div>
				<button type="submit" class="lar-btn lar-submit">Recevoir mon reçu fiscal</button>
				<p class="lar-cerfa-msg" role="status"></p>
			</form>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

// Relais entre la page et le serveur de paiement (aucune donnée personnelle dans l'adresse de la page).
add_action( 'wp_ajax_nopriv_lar_don', 'lar_ajax_don' );
add_action( 'wp_ajax_lar_don', 'lar_ajax_don' );

function lar_api( $path, $body = null ) {
	$args = array( 'timeout' => 25, 'headers' => array( 'Content-Type' => 'application/json' ) );
	if ( null === $body ) {
		$r = wp_remote_get( LAR_PAY_API . $path, $args );
	} else {
		$args['body'] = wp_json_encode( $body );
		$r            = wp_remote_post( LAR_PAY_API . $path, $args );
	}
	if ( is_wp_error( $r ) ) {
		return array( 'ok' => false, 'error' => 'Le service de paiement ne répond pas. Réessayez.' );
	}
	$data = json_decode( wp_remote_retrieve_body( $r ), true );
	return is_array( $data ) ? $data : array( 'ok' => false, 'error' => 'Réponse du paiement invalide.' );
}

function lar_ajax_don() {
	nocache_headers();
	$ref = isset( $_POST['ref'] ) ? sanitize_text_field( wp_unslash( $_POST['ref'] ) ) : '';
	$id  = lar_check_ref( $ref );
	if ( ! $id ) {
		wp_send_json( array( 'ok' => false, 'error' => 'Lettre introuvable.' ) );
	}
	global $wpdb;
	$table = $wpdb->prefix . LAR_TABLE;
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) ); // phpcs:ignore
	if ( ! $row ) {
		wp_send_json( array( 'ok' => false, 'error' => 'Lettre introuvable.' ) );
	}
	$op = isset( $_POST['op'] ) ? sanitize_key( $_POST['op'] ) : '';

	if ( 'create' === $op ) {
		if ( 0 === strpos( $row->don_statut, 'paye' ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'Votre don a déjà été reçu. Merci !' ) );
		}
		$cents = isset( $_POST['cents'] ) ? absint( $_POST['cents'] ) : 0;
		if ( $cents < 100 || $cents > 2000000 ) {
			wp_send_json( array( 'ok' => false, 'error' => 'Montant invalide (minimum 1 €).' ) );
		}
		$config = lar_api( '/config' );
		if ( empty( $config['enabled'] ) || empty( $config['publishableKey'] ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'Le paiement est momentanément indisponible.' ) );
		}
		$req = isset( $_POST['requestId'] ) ? sanitize_text_field( wp_unslash( $_POST['requestId'] ) ) : '';
		$res = lar_api( '/create', array(
			'requestId'   => $req,
			'amountCents' => $cents,
			'email'       => $row->email,
			'prenom'      => $row->prenom,
			'nom'         => $row->nom,
			'ref'         => (string) $id,
		) );
		if ( empty( $res['ok'] ) ) {
			wp_send_json( $res );
		}
		$wpdb->update( $table, array( 'don_cents' => $cents, 'don_statut' => 'choisi', 'don_pi' => $res['paymentIntentId'] ), array( 'id' => $id ) );
		wp_send_json( array(
			'ok'             => true,
			'publishableKey' => $config['publishableKey'],
			'clientSecret'   => $res['clientSecret'],
			'paymentIntent'  => $res['paymentIntentId'],
			'email'          => $row->email,
			'name'           => trim( $row->prenom . ' ' . $row->nom ),
		) );
	}

	if ( 'confirm' === $op ) {
		$pi  = isset( $_POST['pi'] ) ? sanitize_text_field( wp_unslash( $_POST['pi'] ) ) : '';
		$res = lar_api( '/confirm', array( 'paymentIntentId' => $pi ) );
		if ( ! empty( $res['paid'] ) && (string) $id === (string) ( $res['lettreRef'] ?? '' ) ) {
			if ( 0 !== strpos( (string) $row->don_statut, 'paye' ) ) {
				$wpdb->update( $table, array( 'don_cents' => (int) $res['amountCents'], 'don_statut' => 'paye', 'don_pi' => $pi ), array( 'id' => $id ) );
				lar_send_don_merci( $row, (int) $res['amountCents'] );
			}
			wp_send_json( array( 'ok' => true, 'paid' => true, 'amountCents' => (int) $res['amountCents'], 'prenom' => $row->prenom, 'nom' => $row->nom, 'email' => $row->email, 'telephone' => $row->telephone ) );
		}
		wp_send_json( array( 'ok' => false, 'error' => $res['error'] ?? 'Le paiement est en cours de vérification. Ne payez pas une seconde fois.' ) );
	}

	if ( 'cerfa' === $op ) {
		if ( 'paye_cerfa' === $row->don_statut ) {
			wp_send_json( array( 'ok' => true, 'deja' => true ) );
		}
		if ( 'paye' !== $row->don_statut || ! $row->don_pi ) {
			wp_send_json( array( 'ok' => false, 'error' => 'Aucun don payé pour cette lettre.' ) );
		}
		$res = lar_api( '/cerfa', array(
			'paymentIntentId' => $row->don_pi,
			'prenom'          => sanitize_text_field( wp_unslash( $_POST['prenom'] ?? '' ) ),
			'nom'             => sanitize_text_field( wp_unslash( $_POST['nom'] ?? '' ) ),
			'adresse'         => sanitize_text_field( wp_unslash( $_POST['adresse'] ?? '' ) ),
			'telephone'       => sanitize_text_field( wp_unslash( $_POST['telephone'] ?? '' ) ),
			'email'           => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ),
		) );
		if ( ! empty( $res['ok'] ) ) {
			$wpdb->update( $table, array( 'don_statut' => 'paye_cerfa' ), array( 'id' => $id ) );
		}
		wp_send_json( $res );
	}

	wp_send_json( array( 'ok' => false, 'error' => 'Action inconnue.' ) );
}

function lar_hebrew_line( $f ) {
	$line = trim( $f['nom_hebreu'] );
	if ( '' !== $line && '' !== trim( $f['nom_mere'] ) ) {
		$line .= ' ben/bat ' . trim( $f['nom_mere'] );
	}
	return $line;
}

function lar_send_to_ohel( $f ) {
	$s    = lar_settings();
	$to   = is_email( $s['to'] ) ? $s['to'] : LAR_DEFAULT_TO;
	$full = trim( $f['prenom'] . ' ' . $f['nom'] );
	$heb  = lar_hebrew_line( $f );

	$subject = 'Letter to the Rebbe – ' . ( $heb ? $heb : $full );

	$body  = "LETTER TO THE REBBE / LETTRE AU RABBI\n";
	$body .= "=====================================\n\n";
	if ( $heb ) {
		$body .= "Hebrew name / Nom hébreu : " . $heb . "\n";
	}
	$body .= "Name / Nom : " . $full . "\n";
	if ( $f['ville'] ) {
		$body .= "City / Ville : " . $f['ville'] . "\n";
	}
	$body .= "Email : " . $f['email'] . "\n";
	if ( $f['telephone'] ) {
		$body .= "Phone / Tél. : " . $f['telephone'] . "\n";
	}
	if ( $f['personnes'] ) {
		$body .= "\nBlessings requested for / Bénédictions pour :\n" . $f['personnes'] . "\n";
	}
	$body .= "\n-------------------------------------\n\n";
	$body .= $f['lettre'] . "\n\n";
	$body .= "-------------------------------------\n";
	$body .= "Sent via / Envoyé via Beth Habad S Maurice Plateau (France) – " . home_url( '/' ) . "\n";

	$headers   = array( 'Content-Type: text/plain; charset=UTF-8', lar_from_header() );
	$headers[] = 'Reply-To: ' . str_replace( array( "\r", "\n", '<', '>', '"' ), '', $full ) . ' <' . $f['email'] . '>';
	if ( ! empty( $s['copy'] ) ) {
		foreach ( array_map( 'trim', explode( ',', $s['copy'] ) ) as $c ) {
			if ( is_email( $c ) ) {
				$headers[] = 'Bcc: ' . $c;
			}
		}
	}

	return (bool) wp_mail( $to, $subject, $body, $headers );
}

define( 'LAR_LOGO', 'https://habadsmaurice.com/wp-content/uploads/2026/09/cropped-logo-Habad-s-Maurice.png' );

// Expéditeur affiché « Beth Habad S Maurice » (adresse du site, pour rester hors spam).
function lar_from_header() {
	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	$host = preg_replace( '/^www\./', '', (string) $host );
	return 'From: Beth Habad S Maurice <wordpress@' . $host . '>';
}

/**
 * Gabarit HTML commun des e-mails (compatible Gmail, Outlook, Apple Mail).
 * $blocks : HTML déjà échappé du contenu principal.
 */
function lar_email_layout( $preheader, $title, $blocks ) {
	$navy  = '#14213d';
	$gold  = '#b8913a';
	$serif = "Georgia,'Times New Roman',serif";
	$sans  = "'Helvetica Neue',Helvetica,Arial,sans-serif";
	ob_start();
	?>
<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title><?php echo esc_html( $title ); ?></title></head>
<body style="margin:0;padding:0;background:#f4f1ea;">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:#f4f1ea;"><?php echo esc_html( $preheader ); ?></div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f4f1ea;">
<tr><td align="center" style="padding:32px 12px;">
	<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:600px;background:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 6px 24px rgba(20,33,61,.08);">
		<tr><td style="height:5px;background:<?php echo $gold; ?>;font-size:0;line-height:0;">&nbsp;</td></tr>
		<tr><td align="center" style="padding:34px 30px 18px;background:#ffffff;">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="text-decoration:none;"><img src="<?php echo esc_url( LAR_LOGO ); ?>" width="150" alt="Beth Habad S Maurice Plateau" style="display:block;width:150px;max-width:150px;height:auto;border:0;"></a>
		</td></tr>
		<tr><td align="center" style="padding:0 30px;">
			<div style="width:130px;margin:0 auto;border-top:1px solid <?php echo $gold; ?>;line-height:0;font-size:0;text-align:center;"><span style="display:inline-block;background:#ffffff;padding:0 9px;color:<?php echo $gold; ?>;font-size:13px;line-height:13px;position:relative;top:-7px;font-family:<?php echo $serif; ?>;">&#10022;</span></div>
		</td></tr>
		<tr><td align="center" style="padding:18px 40px 6px;font-family:<?php echo $serif; ?>;font-size:30px;line-height:1.25;color:<?php echo $navy; ?>;font-weight:normal;"><?php echo esc_html( $title ); ?></td></tr>
		<tr><td style="padding:14px 44px 34px;font-family:<?php echo $sans; ?>;font-size:16px;line-height:1.7;color:#333333;">
			<?php echo $blocks; // phpcs:ignore ?>
		</td></tr>
		<tr><td style="background:<?php echo $navy; ?>;padding:28px 40px;font-family:<?php echo $sans; ?>;font-size:13px;line-height:1.7;color:#cfd6e6;" align="center">
			<div style="font-family:<?php echo $serif; ?>;font-size:18px;color:#ffffff;margin-bottom:6px;">Beth Habad S Maurice Plateau</div>
			30 avenue du Maréchal de Lattre de Tassigny, 94410 S Maurice<br>
			<a href="mailto:bhsmaurice@gmail.com" style="color:#e9d9b0;text-decoration:none;">bhsmaurice@gmail.com</a>
			&nbsp;·&nbsp; <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:#e9d9b0;text-decoration:none;">habadsmaurice.com</a>
			&nbsp;·&nbsp; <a href="https://www.instagram.com/habadsmaurice" style="color:#e9d9b0;text-decoration:none;">Instagram</a>
		</td></tr>
	</table>
	<div style="font-family:<?php echo $sans; ?>;font-size:11px;color:#9a9384;padding:16px 10px 0;">Vous recevez cet e-mail suite à votre envoi sur habadsmaurice.com.</div>
</td></tr></table>
</body></html>
	<?php
	return ob_get_clean();
}

function lar_email_p( $html ) {
	return '<p style="margin:0 0 16px;">' . $html . '</p>';
}

function lar_email_button( $url, $label ) {
	return '<table role="presentation" cellpadding="0" cellspacing="0" border="0" align="center" style="margin:26px auto 8px;"><tr><td align="center" bgcolor="#b8913a" style="border-radius:40px;">'
		. '<a href="' . esc_url( $url ) . '" style="display:inline-block;padding:15px 34px;font-family:\'Helvetica Neue\',Helvetica,Arial,sans-serif;font-size:16px;font-weight:bold;color:#ffffff;text-decoration:none;border-radius:40px;">' . esc_html( $label ) . '</a>'
		. '</td></tr></table>';
}

function lar_email_box( $title, $html ) {
	return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:22px 0;"><tr><td style="background:#faf7f0;border:1px solid #ece3cc;border-left:4px solid #b8913a;border-radius:8px;padding:18px 22px;">'
		. '<div style="font-family:Georgia,serif;font-size:17px;color:#14213d;margin-bottom:8px;">' . esc_html( $title ) . '</div>'
		. '<div style="font-size:15px;line-height:1.7;color:#444;">' . $html . '</div></td></tr></table>';
}

function lar_send_confirmation( $f, $id = 0, $don_cents = 0 ) {
	$heb   = lar_hebrew_line( $f );
	$body  = lar_email_p( 'Bonjour ' . esc_html( $f['prenom'] ) . ',' );
	$body .= lar_email_p( 'Votre lettre au Rabbi a bien été <strong>transmise à l\'Ohel</strong>, à New York. Elle y sera imprimée et déposée sur le lieu de repos du Rabbi.' );
	$body .= lar_email_p( 'Qu\'Hachem accorde toutes vos demandes pour le bien, avec des bénédictions abondantes et visibles.' );

	$recap  = '<strong>Nom :</strong> ' . esc_html( trim( $f['prenom'] . ' ' . $f['nom'] ) ) . '<br>';
	if ( $heb ) {
		$recap .= '<strong>Nom hébreu :</strong> <span dir="auto">' . esc_html( $heb ) . '</span><br>';
	}
	$recap .= '<strong>Date :</strong> ' . esc_html( date_i18n( 'j F Y à H\hi' ) );
	$body  .= lar_email_box( 'Récapitulatif', $recap );

	if ( $don_cents > 0 && $id ) {
		$url   = add_query_arg( array( 'lettre' => 'ok', 'ref' => lar_make_ref( $id ), 'don' => (int) $don_cents ), get_permalink( (int) get_option( 'lar_page_id' ) ) ?: home_url( '/' . LAR_SLUG . '/' ) ) . '#lar-don';
		$body .= lar_email_p( 'Vous avez souhaité accompagner votre lettre d\'une tsedaka de <strong>' . esc_html( number_format_i18n( $don_cents / 100 ) ) . '&nbsp;€</strong>. Si le paiement n\'a pas encore été fait, vous pouvez le finaliser ici (Apple&nbsp;Pay, Google&nbsp;Pay ou carte)&nbsp;:' );
		$body .= lar_email_button( $url, 'Finaliser mon don de ' . number_format_i18n( $don_cents / 100 ) . ' €' );
	}

	$letter = $f['personnes'] ? '<em>Bénédictions pour&nbsp;:</em><br>' . nl2br( esc_html( $f['personnes'] ) ) . '<br><br>' : '';
	$letter .= nl2br( esc_html( $f['lettre'] ) );
	$body  .= lar_email_box( 'Votre lettre', '<div dir="auto">' . $letter . '</div>' );

	$body .= '<div style="font-family:Georgia,serif;font-size:20px;color:#14213d;margin:28px 0 8px;">Et maintenant&nbsp;?</div>';
	$body .= lar_email_p( 'Prenez sur vous une <strong>bonne résolution</strong> — une mitsva, un moment d\'étude, un geste de bonté. C\'est le meilleur réceptacle pour la bénédiction.' );
	$body .= lar_email_p( 'Si vous souhaitez en parler, trouver votre nom hébreu ou être accompagné, le Rav et l\'équipe du Beth Habad sont à votre écoute&nbsp;: il suffit de répondre à cet e-mail.' );
	$body .= '<p style="margin:26px 0 0;font-family:Georgia,serif;font-size:17px;color:#14213d;">Avec toutes nos bénédictions,<br><span style="color:#b8913a;">Le Beth Habad S Maurice Plateau</span></p>';

	$html = lar_email_layout( 'Votre lettre a bien été transmise à l\'Ohel, à New York.', 'Votre lettre au Rabbi a bien été transmise', $body );
	wp_mail( $f['email'], 'Votre lettre au Rabbi a bien été transmise', $html, array( 'Content-Type: text/html; charset=UTF-8', lar_from_header(), 'Reply-To: Beth Habad S Maurice <bhsmaurice@gmail.com>' ) );
}

function lar_send_don_merci( $row, $cents ) {
	$montant = number_format_i18n( $cents / 100, ( $cents % 100 ) ? 2 : 0 ) . ' €';
	$body    = lar_email_p( 'Bonjour ' . esc_html( $row->prenom ) . ',' );
	$body   .= lar_email_p( 'Nous avons bien reçu votre tsedaka de <strong>' . esc_html( $montant ) . '</strong>, qui accompagne votre lettre au Rabbi. Du fond du cœur, merci&nbsp;!' );
	$body   .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:24px 0;"><tr><td align="center" style="background:#14213d;border-radius:12px;padding:26px 20px;">'
		. '<div style="font-family:Helvetica,Arial,sans-serif;font-size:12px;letter-spacing:3px;text-transform:uppercase;color:#e9d9b0;">Votre don</div>'
		. '<div style="font-family:Georgia,serif;font-size:42px;color:#ffffff;margin-top:6px;">' . esc_html( $montant ) . '</div>'
		. '<div style="font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#cfd6e6;margin-top:6px;">' . esc_html( date_i18n( 'j F Y' ) ) . '</div>'
		. '</td></tr></table>';
	$body   .= lar_email_p( 'Votre générosité fait vivre le Beth Habad&nbsp;: les offices, les cours de Torah, les activités pour les enfants et l\'aide aux familles de la communauté.' );
	$body   .= lar_email_box( 'Reçu fiscal (Cerfa)', 'Si vous l\'avez demandé sur la page après votre paiement, il vous est envoyé par e-mail et WhatsApp. Sinon, <strong>répondez simplement à cet e-mail</strong> avec votre adresse postale et nous vous l\'enverrons.' );
	$body   .= '<p style="margin:26px 0 0;font-family:Georgia,serif;font-size:17px;color:#14213d;">Tizkou lemitsvot,<br><span style="color:#b8913a;">Le Beth Habad S Maurice Plateau</span></p>';
	$html    = lar_email_layout( 'Merci pour votre tsedaka de ' . $montant . '.', 'Merci pour votre tsedaka', $body );
	wp_mail( $row->email, 'Merci pour votre tsedaka de ' . $montant, $html, array( 'Content-Type: text/html; charset=UTF-8', lar_from_header(), 'Reply-To: Beth Habad S Maurice <bhsmaurice@gmail.com>' ) );
}

/* =========================================================================
 * 5. BACK OFFICE
 * ========================================================================= */

add_action( 'admin_menu', function () {
	global $wpdb;
	$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}" . LAR_TABLE . " WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)" ); // phpcs:ignore
	$badge = $count ? ' <span class="awaiting-mod">' . $count . '</span>' : '';
	add_menu_page( 'Lettres au Rabbi', 'Lettres au Rabbi' . $badge, 'manage_options', 'lar-lettres', 'lar_admin_page', 'dashicons-email-alt', 26 );
	add_submenu_page( 'lar-lettres', 'Toutes les lettres', 'Toutes les lettres', 'manage_options', 'lar-lettres', 'lar_admin_page' );
	add_submenu_page( 'lar-lettres', 'Réglages', 'Réglages', 'manage_options', 'lar-reglages', 'lar_settings_page' );
} );

function lar_admin_styles() {
	echo '<style>
	.lar-admin .lar-top{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;margin:16px 0}
	.lar-admin .lar-top form{display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap}
	.lar-admin .lar-top label{display:flex;flex-direction:column;font-size:12px;color:#555}
	.lar-admin .lar-stats{display:flex;gap:12px;margin:12px 0}
	.lar-admin .lar-stat{background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:12px 18px}
	.lar-admin .lar-stat b{display:block;font-size:22px;color:#1d2a4d}
	.lar-admin .lar-ok{color:#008a20;font-weight:600}.lar-admin .lar-ko{color:#d63638;font-weight:600}
	.lar-admin .lar-letter{background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:20px;white-space:pre-wrap;font-size:14px;line-height:1.6;max-width:900px}
	.lar-admin .lar-meta td{padding:6px 12px 6px 0}.lar-admin .lar-meta th{text-align:left;padding:6px 16px 6px 0;color:#555}
	.lar-admin td.lar-excerpt{color:#555;max-width:340px}
	</style>';
}

function lar_where_from_request( &$args ) {
	global $wpdb;
	$where = array( '1=1' );
	$args  = array();
	$q     = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
	$from  = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
	$to    = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
	if ( $q ) {
		$like    = '%' . $wpdb->esc_like( $q ) . '%';
		$where[] = '(prenom LIKE %s OR nom LIKE %s OR email LIKE %s OR telephone LIKE %s OR nom_hebreu LIKE %s OR ville LIKE %s)';
		array_push( $args, $like, $like, $like, $like, $like, $like );
	}
	if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
		$where[] = 'created_at >= %s';
		$args[]  = $from . ' 00:00:00';
	}
	if ( $to && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
		$where[] = 'created_at <= %s';
		$args[]  = $to . ' 23:59:59';
	}
	return implode( ' AND ', $where );
}

function lar_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	global $wpdb;
	$table = $wpdb->prefix . LAR_TABLE;
	lar_admin_styles();

	// Vue détaillée d'une lettre.
	if ( isset( $_GET['voir'] ) ) {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", absint( $_GET['voir'] ) ) ); // phpcs:ignore
		echo '<div class="wrap lar-admin">';
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=lar-lettres' ) ) . '">← Retour à la liste</a></p>';
		if ( ! $row ) {
			echo '<p>Lettre introuvable.</p></div>';
			return;
		}
		echo '<h1>Lettre de ' . esc_html( $row->prenom . ' ' . $row->nom ) . '</h1>';
		if ( isset( $_GET['renvoye'] ) ) {
			echo '<div class="notice notice-' . ( '1' === $_GET['renvoye'] ? 'success' : 'error' ) . '"><p>' . ( '1' === $_GET['renvoye'] ? 'Lettre renvoyée à l\'Ohel.' : 'Échec de l\'envoi. Vérifiez la configuration e-mail du site (plugin SMTP).' ) . '</p></div>';
		}
		echo '<table class="lar-meta">';
		$rows = array(
			'Date'                  => date_i18n( 'd/m/Y à H:i', strtotime( $row->created_at ) ),
			'Prénom / Nom'          => $row->prenom . ' ' . $row->nom,
			'E-mail'                => '<a href="mailto:' . esc_attr( $row->email ) . '">' . esc_html( $row->email ) . '</a>',
			'Téléphone'             => $row->telephone,
			'Ville'                 => $row->ville,
			'Nom hébreu'            => lar_hebrew_line( (array) $row ),
			'Envoyée à l\'Ohel'     => $row->mail_sent ? '<span class="lar-ok">Oui</span>' : '<span class="lar-ko">Non</span>',
			'Don'                   => lar_don_label( $row ),
		);
		foreach ( $rows as $k => $v ) {
			$safe = in_array( $k, array( 'E-mail', 'Envoyée à l\'Ohel', 'Don' ), true ) ? $v : esc_html( $v );
			echo '<tr><th>' . esc_html( $k ) . '</th><td>' . $safe . '</td></tr>'; // phpcs:ignore
		}
		echo '</table>';
		if ( $row->personnes ) {
			echo '<h2>Bénédictions demandées pour</h2><div class="lar-letter" dir="auto">' . esc_html( $row->personnes ) . '</div>';
		}
		echo '<h2>Lettre</h2><div class="lar-letter" dir="auto">' . esc_html( $row->lettre ) . '</div>';
		$resend = wp_nonce_url( admin_url( 'admin-post.php?action=lar_resend&id=' . $row->id ), 'lar_resend_' . $row->id );
		$del    = wp_nonce_url( admin_url( 'admin-post.php?action=lar_delete&id=' . $row->id ), 'lar_delete_' . $row->id );
		echo '<p style="margin-top:20px"><a class="button button-primary" href="' . esc_url( $resend ) . '">Renvoyer à l\'Ohel</a> ';
		echo '<a class="button" href="mailto:' . esc_attr( $row->email ) . '">Répondre par e-mail</a> ';
		echo '<a class="button" style="color:#d63638" href="' . esc_url( $del ) . '" onclick="return confirm(\'Supprimer définitivement cette lettre ?\')">Supprimer</a></p>';
		echo '</div>';
		return;
	}

	// Liste.
	$args  = array();
	$where = lar_where_from_request( $args );
	$per   = 30;
	$paged = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
	$off   = ( $paged - 1 ) * $per;

	$count_sql = "SELECT COUNT(*) FROM $table WHERE $where";
	$list_sql  = "SELECT * FROM $table WHERE $where ORDER BY created_at DESC LIMIT %d OFFSET %d";
	$total     = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count_sql, $args ) ) : $wpdb->get_var( $count_sql ) ); // phpcs:ignore
	$items     = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $args, array( $per, $off ) ) ) ); // phpcs:ignore

	$all     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ); // phpcs:ignore
	$month   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE created_at >= DATE_FORMAT(NOW(),'%Y-%m-01')" ); // phpcs:ignore
	$emails  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT email) FROM $table" ); // phpcs:ignore
	$dons    = (int) $wpdb->get_var( "SELECT COALESCE(SUM(don_cents),0) FROM $table WHERE don_statut LIKE 'paye%'" ); // phpcs:ignore

	$q    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
	$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
	$to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';

	$export = wp_nonce_url( add_query_arg( array( 'action' => 'lar_export', 's' => $q, 'from' => $from, 'to' => $to ), admin_url( 'admin-post.php' ) ), 'lar_export' );

	echo '<div class="wrap lar-admin"><h1 class="wp-heading-inline">Lettres au Rabbi</h1>';
	echo ' <a href="' . esc_url( $export ) . '" class="page-title-action">⬇ Télécharger en Excel (CSV)</a>';
	$page_id = (int) get_option( 'lar_page_id' );
	if ( $page_id && get_post( $page_id ) ) {
		echo ' <a href="' . esc_url( get_permalink( $page_id ) ) . '" class="page-title-action" target="_blank">Voir la page</a>';
	}
	if ( isset( $_GET['supprime'] ) ) {
		echo '<div class="notice notice-success is-dismissible"><p>Lettre supprimée.</p></div>';
	}

	echo '<div class="lar-stats">';
	echo '<div class="lar-stat"><b>' . $all . '</b>lettres au total</div>';
	echo '<div class="lar-stat"><b>' . $month . '</b>ce mois-ci</div>';
	echo '<div class="lar-stat"><b>' . $emails . '</b>personnes (e-mails uniques)</div>';
	echo '<div class="lar-stat"><b>' . esc_html( number_format_i18n( $dons / 100 ) ) . ' €</b>de dons reçus</div>';
	echo '</div>';

	echo '<div class="lar-top"><form method="get">';
	echo '<input type="hidden" name="page" value="lar-lettres">';
	echo '<label>Rechercher (nom, e-mail, tél.)<input type="search" name="s" value="' . esc_attr( $q ) . '"></label>';
	echo '<label>Du<input type="date" name="from" value="' . esc_attr( $from ) . '"></label>';
	echo '<label>Au<input type="date" name="to" value="' . esc_attr( $to ) . '"></label>';
	echo '<button class="button">Filtrer</button>';
	if ( $q || $from || $to ) {
		echo ' <a class="button-link" href="' . esc_url( admin_url( 'admin.php?page=lar-lettres' ) ) . '">Réinitialiser</a>';
	}
	echo '</form></div>';

	echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Nom</th><th>Prénom</th><th>E-mail</th><th>Téléphone</th><th>Nom hébreu</th><th>Extrait</th><th>Don</th><th>Ohel</th><th></th></tr></thead><tbody>';
	if ( ! $items ) {
		echo '<tr><td colspan="10">Aucune lettre pour le moment.</td></tr>';
	}
	foreach ( $items as $r ) {
		$voir    = admin_url( 'admin.php?page=lar-lettres&voir=' . $r->id );
		$excerpt = wp_html_excerpt( $r->lettre, 80, '…' );
		echo '<tr>';
		echo '<td>' . esc_html( date_i18n( 'd/m/Y H:i', strtotime( $r->created_at ) ) ) . '</td>';
		echo '<td><strong><a href="' . esc_url( $voir ) . '">' . esc_html( $r->nom ) . '</a></strong></td>';
		echo '<td>' . esc_html( $r->prenom ) . '</td>';
		echo '<td><a href="mailto:' . esc_attr( $r->email ) . '">' . esc_html( $r->email ) . '</a></td>';
		echo '<td>' . esc_html( $r->telephone ) . '</td>';
		echo '<td dir="auto">' . esc_html( lar_hebrew_line( (array) $r ) ) . '</td>';
		echo '<td class="lar-excerpt" dir="auto">' . esc_html( $excerpt ) . '</td>';
		echo '<td>' . lar_don_label( $r ) . '</td>'; // phpcs:ignore
		echo '<td>' . ( $r->mail_sent ? '<span class="lar-ok">✔</span>' : '<span class="lar-ko" title="Non envoyée">✖</span>' ) . '</td>';
		echo '<td><a class="button button-small" href="' . esc_url( $voir ) . '">Lire</a></td>';
		echo '</tr>';
	}
	echo '</tbody></table>';

	$pages = (int) ceil( $total / $per );
	if ( $pages > 1 ) {
		echo '<div class="tablenav"><div class="tablenav-pages">' . paginate_links( array(
			'base'    => add_query_arg( 'paged', '%#%' ),
			'format'  => '',
			'current' => $paged,
			'total'   => $pages,
		) ) . '</div></div>';
	}
	echo '<p style="color:#666">' . $total . ' résultat(s).</p></div>';
}

// Export CSV (s'ouvre directement dans Excel : UTF-8 + séparateur point-virgule).
add_action( 'admin_post_lar_export', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'lar_export' ) ) {
		wp_die( 'Accès refusé.' );
	}
	global $wpdb;
	$table = $wpdb->prefix . LAR_TABLE;
	$args  = array();
	$where = lar_where_from_request( $args );
	$sql   = "SELECT * FROM $table WHERE $where ORDER BY created_at DESC";
	$rows  = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore

	nocache_headers();
	header( 'Content-Type: text/csv; charset=UTF-8' );
	header( 'Content-Disposition: attachment; filename="lettres-au-rabbi-' . gmdate( 'Y-m-d' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" );
	fputcsv( $out, array( 'Date', 'Prénom', 'Nom', 'E-mail', 'Téléphone', 'Ville', 'Prénom hébreu', 'Prénom hébreu de la mère', 'Bénédictions pour', 'Lettre', 'Envoyée à l\'Ohel', 'Don (€)', 'Statut du don' ), ';' );
	foreach ( $rows as $r ) {
		$cells = array(
			date_i18n( 'd/m/Y H:i', strtotime( $r['created_at'] ) ),
			$r['prenom'], $r['nom'], $r['email'], $r['telephone'], $r['ville'],
			$r['nom_hebreu'], $r['nom_mere'], $r['personnes'], $r['lettre'],
			$r['mail_sent'] ? 'Oui' : 'Non',
			$r['don_cents'] ? number_format( $r['don_cents'] / 100, 2, ',', '' ) : '',
			lar_don_statut_text( $r['don_statut'] ),
		);
		// Protection contre l'injection de formules Excel.
		$cells = array_map( function ( $c ) {
			$c = (string) $c;
			return ( '' !== $c && in_array( $c[0], array( '=', '+', '-', '@' ), true ) ) ? "'" . $c : $c;
		}, $cells );
		fputcsv( $out, $cells, ';' );
	}
	fclose( $out );
	exit;
} );

add_action( 'admin_post_lar_resend', function () {
	$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'lar_resend_' . $id ) ) {
		wp_die( 'Accès refusé.' );
	}
	global $wpdb;
	$table = $wpdb->prefix . LAR_TABLE;
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
	$ok    = $row ? lar_send_to_ohel( $row ) : false;
	if ( $ok ) {
		$wpdb->update( $table, array( 'mail_sent' => 1 ), array( 'id' => $id ) );
	}
	wp_safe_redirect( admin_url( 'admin.php?page=lar-lettres&voir=' . $id . '&renvoye=' . ( $ok ? '1' : '0' ) ) );
	exit;
} );

add_action( 'admin_post_lar_delete', function () {
	$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'lar_delete_' . $id ) ) {
		wp_die( 'Accès refusé.' );
	}
	global $wpdb;
	$wpdb->delete( $wpdb->prefix . LAR_TABLE, array( 'id' => $id ) );
	wp_safe_redirect( admin_url( 'admin.php?page=lar-lettres&supprime=1' ) );
	exit;
} );

/* Réglages */
add_action( 'admin_init', function () {
	register_setting( 'lar_settings_group', 'lar_settings', array(
		'sanitize_callback' => function ( $in ) {
			return array(
				'to'      => is_email( $in['to'] ?? '' ) ? sanitize_email( $in['to'] ) : LAR_DEFAULT_TO,
				'copy'    => sanitize_text_field( $in['copy'] ?? '' ),
				'confirm' => empty( $in['confirm'] ) ? 0 : 1,
			);
		},
	) );
} );

function lar_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s = lar_settings();
	?>
	<div class="wrap">
		<h1>Lettres au Rabbi – Réglages</h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'lar_settings_group' ); ?>
			<table class="form-table">
				<tr><th>Adresse de l'Ohel</th><td><input type="email" class="regular-text" name="lar_settings[to]" value="<?php echo esc_attr( $s['to'] ); ?>"><p class="description">Par défaut : ohel@ohelchabad.org</p></td></tr>
				<tr><th>Recevoir une copie</th><td><input type="text" class="regular-text" name="lar_settings[copy]" value="<?php echo esc_attr( $s['copy'] ); ?>" placeholder="ex. bhsmaurice@gmail.com"><p class="description">Facultatif. Une ou plusieurs adresses séparées par des virgules (copie cachée).</p></td></tr>
				<tr><th>E-mail de confirmation</th><td><label><input type="checkbox" name="lar_settings[confirm]" value="1" <?php checked( $s['confirm'], 1 ); ?>> Envoyer un e-mail de confirmation à la personne</label></td></tr>
			</table>
			<?php submit_button( 'Enregistrer' ); ?>
		</form>
		<hr>
		<h2>Utilisation</h2>
		<p>La page <strong>« Écrire au Rabbi »</strong> (adresse : <code>/<?php echo esc_html( LAR_SLUG ); ?>/</code>) a été créée automatiquement. Vous pouvez aussi placer le formulaire sur n'importe quelle page avec le code court <code>[lettre_au_rabbi]</code>.</p>
		<p><strong>Important :</strong> pour que les e-mails arrivent bien à l'Ohel (et pas en spam), installez le plugin gratuit <em>WP Mail SMTP</em> et connectez-le à une vraie boîte e-mail (Gmail, Brevo…).</p>
	</div>
	<?php
}

// Image de partage (Yoast) : la photo du Rabbi si aucune image n'est définie.
add_filter( 'wpseo_opengraph_image', function ( $img ) {
	return ( lar_is_page() && ! $img ) ? LAR_IMG_RABBI : $img;
} );

// Masque le titre automatique du thème sur la page (évite deux titres H1).
add_filter( 'hello_elementor_page_title', function ( $show ) {
	return lar_is_page() ? false : $show;
} );
add_action( 'wp_head', function () {
	if ( lar_is_page() ) {
		echo '<style>.page-header .entry-title,.entry-header .entry-title{display:none}.lar-wrap a{text-decoration:none!important}html,body{overflow-x:clip}</style>';
	}
}, 99 );

function lar_don_statut_text( $statut ) {
	$map = array( 'choisi' => 'Choisi, non payé', 'paye' => 'Payé', 'paye_cerfa' => 'Payé + Cerfa demandé' );
	return $map[ $statut ] ?? '';
}

function lar_don_label( $r ) {
	$r = (object) $r;
	if ( empty( $r->don_cents ) ) {
		return '<span style="color:#999">—</span>';
	}
	$m = esc_html( number_format_i18n( $r->don_cents / 100 ) ) . '&nbsp;€';
	if ( 0 === strpos( (string) $r->don_statut, 'paye' ) ) {
		return '<span class="lar-ok">' . $m . ' ✔</span>' . ( 'paye_cerfa' === $r->don_statut ? ' <small>Cerfa</small>' : '' );
	}
	return '<span style="color:#996800" title="Montant choisi mais pas encore payé">' . $m . ' (non payé)</span>';
}

// Lien « Réglages » dans la liste des extensions.
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=lar-lettres' ) ) . '">Voir les lettres</a>' );
	return $links;
} );
